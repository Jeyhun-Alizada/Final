"use strict";
// GIF FOR LOADING START
window.onload = function() {
  let preloader = this.document.getElementById("preloader");
    preloader.classList.add("hide");
    setTimeout(() => {
      preloader.classList.add("d-none");
    }, 100);
  };
// GIF FOR LOADING END
// NAV AFTER 500PX DOWN START
  $(document).ready(function() {
    let $topNAvBar = $(".topNavBar"),
      topNavBarActive = "topNavBarActive",
      activateAtY = 500;
    function deactivateHeader() {
      if (!$topNAvBar.hasClass(topNavBarActive)) {
        $topNAvBar.addClass(topNavBarActive);
      }
    }
    function activateHeader() {
      if ($topNAvBar.hasClass(topNavBarActive)) {
        $topNAvBar.removeClass(topNavBarActive);
      }
    }
    $(window).scroll(function() {
      if ($(window).scrollTop() > activateAtY) {
        deactivateHeader();
      } else {
        activateHeader();
      }
    });
// NAV AFTER 500PX DOWN END
  //MAIN,BLOG, FORUM SLIDER SECTION START
let firstOwl = $(".autoPlay");
firstOwl.owlCarousel({
  items: 1,
  loop: true,
  margin: 10,
  autoplay: true,
  autoplayTimeout: 3500
});
$(".play").on("click", function() {
  owl.trigger("play.owl.autoplay", [1000]);
});
$(".stop").on("click", function() {
  owl.trigger("stop.owl.autoplay");
});
  //MAIN,BLOG, FORUM SLIDER SECTION END
  // RECOMMENDED,SALE, NEW PRODUCTS  SECTION START
  let secondOwl = $(".loop");
  secondOwl.owlCarousel({
    center: true,
    items: 2,
    loop: true,
    margin: 10,
    responsive: {
      600: {
        items: 4
      }
    }
  });
  //RECOMMENDED,SALE, NEW PRODUCTS  SECTION END
  //
  var slider = document.getElementsByClassName("range")[0];
  var output = document.getElementsByClassName("range")[1];
  output.innerHTML = slider.value;
  slider.oninput = function() {
    output.innerHTML = this.value;
  }
});