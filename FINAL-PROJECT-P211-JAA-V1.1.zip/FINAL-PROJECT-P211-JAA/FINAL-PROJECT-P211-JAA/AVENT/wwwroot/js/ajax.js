"use strict;"
$(document).ready(function() {
$(".brend").change(function (e) {
    window.location.replace($(".brend").val());
});
$(".filter").change(function (e) {
    window.location.replace($(".filter").val());
});
$(".range").change(function (e) {
    window.location.replace("https://localhost:44374/Home/Product/<" + $(".range").val());
    $(".spanrange").text($(".range").val());
});
$(".addtocart").click(function (e) {
    e.preventDefault();
    $.ajax({
        url: $(this).attr("href"),
        method: "GET",
        success: ""
    });
    let countsting = $(".count").text();
    let count = parseInt(countsting);
    $(".count").text((count) + 1);
});
$(".removefromcart").click(function (e) {
    e.preventDefault();
    $.ajax({
        url: $(this).attr("href"),
        method: "GET",
        success: ""
    });
    //$(this).parent().parent().addClass("d-none");
    location.reload();
});
$(".quantity").change(function (e) {
    e.preventDefault();
    $.ajax({
        url: "https://localhost:44374/Checkout/Change/" + $(this).attr("data-value") + "m" + $(this).val(),
        method: "GET",
        success: ""
    });
});
$(".updatecart").click(function (e) {
    location.reload();
});
$(".sendorder").click(function (e) {
    e.preventDefault();
    $.ajax({
        url: $(this).attr("href"),
        method: "GET",
        success: ""
    });
    window.location.replace("https://localhost:44374/Profile/Orders");
});
$(".changeorderstatus").click(function (e) {
    e.preventDefault();
    $.ajax({
        url:$(this).attr("href") + "s" + $(".statusNames").val(),
        method: "GET",
        success: ""
    });
    location.reload();
});
$(".addblogcomment").click(function (e) {
    e.preventDefault();
    $.ajax({
        url: "https://localhost:44374/Blog/Comment/" + $(this).attr("data-value") + "c" + $(".blogcomment").val(),
        method: "GET",
        success: ""
    });
    location.reload();
});
$(".addforumcomment").click(function (e) {
    e.preventDefault();
    $.ajax({
        url: "https://localhost:44374/Forum/Comment/" + $(this).attr("data-value") + "c" + $(".forumcomment").val(),
        method: "GET",
        success: ""
    });
    location.reload();
});
$(".search").click(function (e) {
    window.location.replace($(this).attr("href")+ "/%" + $(".searchinput").val());
    alert($(this).attr("href") + "/%" + $(".searchinput").val());
});
$(".removecomment").click(function (e) {
    e.preventDefault();
    $.ajax({
        url:$(this).attr("href"),
        method: "GET",
        success: ""
    });
    location.reload();
});
});