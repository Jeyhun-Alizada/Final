﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AVENT.DAL;
using AVENT.Models;
using static AVENT.Utilities.Utilities;
using Microsoft.AspNetCore.Hosting;

namespace AVENT.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class CategoryController : Controller
    {
        private readonly AventDbContext _context;
        public CategoryController(AventDbContext context)
        {
            _context = context;
        }
        public IActionResult Index(int page = 1)
        {
            @ViewData["totalproductcount"] = _context.ProductCategories.ToList().Count;
            @ViewData["thisePage"] = page;
            int skipcount = (page - 1) * 3;
            var categories = _context.ProductCategories.OrderBy(p => p.Id).Skip(skipcount).Take(3).ToList();
            return View(categories);
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ProductCategory category)
        {
            if (!ModelState.IsValid)
            {
                return View(category);
            }
            await _context.ProductCategories.AddAsync(category);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var oldcategory = await _context.ProductCategories.FindAsync(id);

            if (oldcategory == null) return NotFound();

            return View(oldcategory);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int? id, Product category)
        {
            if (!ModelState.IsValid) return View(category);
            ProductCategory oldcategory = await _context.ProductCategories.FindAsync(id);
            oldcategory.Name = category.Name;
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();
            var category = await _context.ProductCategories.FindAsync(id);
            if (category == null) return NotFound();
            return View(category);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [ActionName("Delete")]
        public async Task<IActionResult> DeletePost(int? id)
        {
            if (id == null) return NotFound();
            var category = await _context.ProductCategories.FindAsync(id);
            if (category == null) return NotFound();
            if (_context.ProductCategories.ToList().Count > 1)
            {
                _context.ProductCategories.Remove(category);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }
    }
}