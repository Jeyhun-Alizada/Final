﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AVENT.DAL;
using AVENT.Models;
using AVENT.Extations;
using AVENT.ViewModels;
using Microsoft.AspNetCore.Hosting;
using static AVENT.Utilities.Utilities;
namespace AVENT.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class ProductController : Controller
    {
        private readonly AventDbContext _context;
        private readonly IHostingEnvironment _env;
        public ProductController(AventDbContext context, IHostingEnvironment env)
        {
            _context = context;
            _env = env;
        }
        public IActionResult Index(int page = 1)
        {
            @ViewData["totalproductcount"] = _context.Products.ToList().Count;
            @ViewData["thisePage"] = page;
            int skipcount = (page - 1) * 9;
            var products = _context.Products.OrderBy(p => p.Id).Skip(skipcount).Take(9).ToList();
            return View(products);
        }
        public IActionResult Create()
        {
            @ViewData["Categories"] = _context.ProductCategories.ToList();
            @ViewData["Brends"] = _context.Brends.ToList();
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Product product)
        {
            if (!ModelState.IsValid)
            {
                return View(product);
            }
            if (product.Photo == null)
            {
                ModelState.AddModelError("Photo", "Photo should be selected");
                return View(product);
            }
            if (!product.Photo.ContentType.Contains("image/"))
            {
                ModelState.AddModelError("Photo", "Photo is not valid");
                return View(product);
            }
            product.Image = await product.Photo.SaveFileAsync(_env.WebRootPath);
            await _context.Products.AddAsync(product);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();
            var product = await _context.Products.FindAsync(id);
            @ViewData["Category"] = _context.ProductCategories.FirstOrDefault(pc => pc.Id == product.ProductCategoryId).Name;
            @ViewData["Brend"] = _context.Brends.FirstOrDefault(pc => pc.Id == product.BrendId).Name;
            if (product == null) return NotFound();
            return View(product);
        }
        public async Task<IActionResult> Edit(int? id)
        {
            @ViewData["Categories"] = _context.ProductCategories.ToList();
            @ViewData["Brends"] = _context.Brends.ToList();

            if (id == null) return NotFound();

            var product = await _context.Products.FindAsync(id);

            if (product == null) return NotFound();

            return View(product);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int? id, Product product)
        {
            if (!ModelState.IsValid) return View(product);
            Product productOld = await _context.Products.FindAsync(id);
            if (product.Photo != null)
            {
                if (product.Photo.IsImage())
                {
                    RemoveFile(productOld.Image, _env.WebRootPath);
                    productOld.Image = await product.Photo.SaveFileAsync(_env.WebRootPath);
                }
                else
                {
                    ModelState.AddModelError("Photo", "Photo is not valid");
                    return View(product);
                }

            }
            productOld.Name = product.Name;
            productOld.Price = product.Price;
            productOld.ProductCategoryId = product.ProductCategoryId;
            productOld.BrendId = product.BrendId;
            productOld.HasDiscount = product.HasDiscount;
            productOld.DiscountPrice = product.DiscountPrice;
            productOld.IfBestseller = product.IfBestseller;
            productOld.IfNew = product.IfNew;
            productOld.Description = product.Description;
            productOld.ImageAlt = product.ImageAlt;
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();
            var product = await _context.Products.FindAsync(id);
            @ViewData["Category"] = _context.ProductCategories.FirstOrDefault(pc => pc.Id == product.ProductCategoryId).Name;
            @ViewData["Brend"] = _context.Brends.FirstOrDefault(pc => pc.Id == product.BrendId).Name;
            if (product == null) return NotFound();
            return View(product);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [ActionName("Delete")]
        public async Task<IActionResult> DeletePost(int? id)
        {
            if (id == null) return NotFound();
            var products = await _context.Products.FindAsync(id);
            if (products == null) return NotFound();
            if (_context.Products.ToList().Count > 1)
            {
                RemoveFile(products.Image, _env.WebRootPath);
                _context.Products.Remove(products);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }
    }
}