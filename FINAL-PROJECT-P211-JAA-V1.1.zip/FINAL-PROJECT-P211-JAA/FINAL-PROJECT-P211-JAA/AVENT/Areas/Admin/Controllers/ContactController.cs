﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AVENT.Models;
using AVENT.DAL;

namespace AVENT.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class ContactController : Controller
    {
        private readonly AventDbContext _context;
        public ContactController(AventDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            ViewData["Message"] = "Your contact page.";
            Contact contact = _context.Contact.First();
            return View(contact);
        }
        public async Task<IActionResult> Edit(int? id)
        {
            var selectedContact = await _context.Contact.FindAsync(id);
            return View(selectedContact);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Contact contact)
        {
            int id = 1;
            var oldContact = await _context.Contact.FindAsync(id);
            oldContact.Adress = contact.Adress;
            oldContact.Phone = contact.Phone;
            oldContact.Email = contact.Email;
            oldContact.WebSite = contact.WebSite;
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}