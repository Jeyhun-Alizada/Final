﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AVENT.DAL;
using AVENT.Models;
using AVENT.Extations;
using AVENT.ViewModels;
using Microsoft.AspNetCore.Hosting;
using static AVENT.Utilities.Utilities;
namespace AVENT.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class AboutController : Controller
    {
        private readonly AventDbContext _context;
        private readonly IHostingEnvironment _env;
        public AboutController(AventDbContext context, IHostingEnvironment env)
        {
            _context = context;
            _env = env;
        }
        public IActionResult Index()
        {
            var about = _context.About.First();
            return View(about);
        }
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var about = await _context.About.FindAsync(id);

            if (about == null) return NotFound();

            return View(about);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int? id, About about)
        {
            if (!ModelState.IsValid) return View(about);
            About aboutOld = await _context.About.FindAsync(id);
            if (about.Photo != null)
            {
                if (about.Photo.IsImage())
                {
                    RemoveFile(aboutOld.Image, _env.WebRootPath);
                    aboutOld.Image = await about.Photo.SaveFileAsync(_env.WebRootPath);
                }
                else
                {
                    ModelState.AddModelError("Photo", "Photo is not valid");
                    return View(about);
                }

            }
            aboutOld.Header = about.Header;
            aboutOld.Info = about.Info;
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}