﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AVENT.DAL;
using AVENT.Models;
using AVENT.Extations;
using AVENT.ViewModels;
using Microsoft.AspNetCore.Hosting;
using static AVENT.Utilities.Utilities;
namespace AVENT.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class PostController : Controller
    {
        private readonly AventDbContext _context;
        private readonly IHostingEnvironment _env;
        public PostController(AventDbContext context, IHostingEnvironment env)
        {
            _context = context;
            _env = env;
        }
        public IActionResult Index(int page = 1)
        {
            @ViewData["totalproductcount"] = _context.Products.ToList().Count;
            @ViewData["thisePage"] = page;
            int skipcount = (page - 1) * 9;
            var blogs = _context.Blogs.OrderBy(p => p.Id).Skip(skipcount).Take(9).ToList();
            var forums = _context.Forums.OrderBy(p => p.Id).Skip(skipcount).Take(9).ToList();
            PostVM postVM = new PostVM
            {
                Blogs = blogs,
                Forums = forums
            };
            return View(postVM);
        }
        public async Task<IActionResult> Edit(int? id)
        {
            @ViewData["Categories"] = _context.ForumCategories.ToList();

            if (id == null) return NotFound();
            var blog = await _context.Blogs.FindAsync(id);
            var forum = await _context.Forums.FindAsync(id);

            if (blog == null && forum == null) return NotFound();
            PostVM postVM = new PostVM
            {
                Blog = blog,
                Forum = forum
            };
            return View(postVM);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [ActionName("EditBlog")]
        public async Task<IActionResult> EditBlog(int? id, Blog blog)
        {
            if (!ModelState.IsValid) return View(blog);
            Blog blogOld = await _context.Blogs.FindAsync(id);
            if (blog.Photo != null)
            {
                if (blog.Photo.IsImage())
                {
                    RemoveFile(blogOld.Image, _env.WebRootPath);
                    blogOld.Image = await blog.Photo.SaveFileAsync(_env.WebRootPath);
                }
                else
                {
                    ModelState.AddModelError("Photo", "Photo is not valid");
                    return View(blog);
                }
            }
            blogOld.Header = blog.Header;
            blogOld.SubHEader = blog.SubHEader;
            blogOld.Description = blog.Description;
            blogOld.ImageAlt = blog.ImageAlt;
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [ActionName("EditForum")]
        public async Task<IActionResult> EditForum(int? id, Forum forum)
        {
            if (!ModelState.IsValid) return View(forum);
            Forum forumOld = await _context.Forums.FindAsync(id);
            if (forum.Photo != null)
            {
                if (forum.Photo.IsImage())
                {
                    RemoveFile(forumOld.Image, _env.WebRootPath);
                    forumOld.Image = await forum.Photo.SaveFileAsync(_env.WebRootPath);
                }
                else
                {
                    ModelState.AddModelError("Photo", "Photo is not valid");
                    return View(forum);
                }

            }
            forumOld.Header = forum.Header;
            forumOld.ForumCategoryId = forum.ForumCategoryId;
            forumOld.Description = forum.Description;
            forumOld.ImageAlt = forum.ImageAlt;
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        public async Task<IActionResult> DeletePost(int? id)
        {
            if (id == null) return NotFound();
            var forum = await _context.Forums.FindAsync(id);
            var blog = await _context.Blogs.FindAsync(id);
            @ViewData["Category"] = _context.ForumCategories.FirstOrDefault(pc => pc.Id == forum.ForumCategoryId).Name;
            if (blog == null && forum == null) return NotFound();
            PostVM postVM = new PostVM
            {
                Blog = blog,
                Forum = forum
            };
            return View(postVM);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [ActionName("DeleteBlog")]
        public async Task<IActionResult> DeleteBlog(int? id)
        {
            if (id == null) return NotFound();
            var blog = await _context.Blogs.FindAsync(id);
            if (blog == null) return NotFound();
            RemoveFile(blog.Image, _env.WebRootPath);
            _context.Blogs.Remove(blog);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [ActionName("DeleteForum")]
        public async Task<IActionResult> DeleteForum(int? id)
        {
            if (id == null) return NotFound();
            var forum = await _context.Forums.FindAsync(id);
            if (forum == null) return NotFound();
            RemoveFile(forum.Image, _env.WebRootPath);
            _context.Forums.Remove(forum);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}