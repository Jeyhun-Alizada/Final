﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AVENT.Migrations
{
    public partial class OrderStatusAddedToOrderDbContex : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
