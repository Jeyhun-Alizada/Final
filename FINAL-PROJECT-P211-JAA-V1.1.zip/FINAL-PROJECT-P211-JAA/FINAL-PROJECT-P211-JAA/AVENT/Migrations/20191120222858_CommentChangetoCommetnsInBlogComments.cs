﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AVENT.Migrations
{
    public partial class CommentChangetoCommetnsInBlogComments : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_BlogComments_Blogs_BlogId",
                table: "BlogComments");

            migrationBuilder.DropForeignKey(
                name: "FK_BlogComments_Comments_CommentId",
                table: "BlogComments");

            migrationBuilder.DropIndex(
                name: "IX_BlogComments_BlogId",
                table: "BlogComments");

            migrationBuilder.DropIndex(
                name: "IX_BlogComments_CommentId",
                table: "BlogComments");

            migrationBuilder.AddColumn<int>(
                name: "BlogCommentsId",
                table: "Comments",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "BlogCommentsId",
                table: "Blogs",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Comments_BlogCommentsId",
                table: "Comments",
                column: "BlogCommentsId");

            migrationBuilder.CreateIndex(
                name: "IX_Blogs_BlogCommentsId",
                table: "Blogs",
                column: "BlogCommentsId");

            migrationBuilder.AddForeignKey(
                name: "FK_Blogs_BlogComments_BlogCommentsId",
                table: "Blogs",
                column: "BlogCommentsId",
                principalTable: "BlogComments",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Comments_BlogComments_BlogCommentsId",
                table: "Comments",
                column: "BlogCommentsId",
                principalTable: "BlogComments",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Blogs_BlogComments_BlogCommentsId",
                table: "Blogs");

            migrationBuilder.DropForeignKey(
                name: "FK_Comments_BlogComments_BlogCommentsId",
                table: "Comments");

            migrationBuilder.DropIndex(
                name: "IX_Comments_BlogCommentsId",
                table: "Comments");

            migrationBuilder.DropIndex(
                name: "IX_Blogs_BlogCommentsId",
                table: "Blogs");

            migrationBuilder.DropColumn(
                name: "BlogCommentsId",
                table: "Comments");

            migrationBuilder.DropColumn(
                name: "BlogCommentsId",
                table: "Blogs");

            migrationBuilder.CreateIndex(
                name: "IX_BlogComments_BlogId",
                table: "BlogComments",
                column: "BlogId");

            migrationBuilder.CreateIndex(
                name: "IX_BlogComments_CommentId",
                table: "BlogComments",
                column: "CommentId");

            migrationBuilder.AddForeignKey(
                name: "FK_BlogComments_Blogs_BlogId",
                table: "BlogComments",
                column: "BlogId",
                principalTable: "Blogs",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_BlogComments_Comments_CommentId",
                table: "BlogComments",
                column: "CommentId",
                principalTable: "Comments",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
