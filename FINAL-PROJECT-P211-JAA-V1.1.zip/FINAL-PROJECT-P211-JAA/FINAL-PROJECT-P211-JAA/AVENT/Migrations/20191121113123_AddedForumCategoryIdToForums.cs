﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AVENT.Migrations
{
    public partial class AddedForumCategoryIdToForums : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Forums_ForumCategories_ForumCategoryId",
                table: "Forums");

            migrationBuilder.DropIndex(
                name: "IX_ForumComments_CommentId",
                table: "ForumComments");

            migrationBuilder.DropIndex(
                name: "IX_BlogComments_CommentId",
                table: "BlogComments");

            migrationBuilder.AlterColumn<int>(
                name: "ForumCategoryId",
                table: "Forums",
                nullable: false,
                oldClrType: typeof(int),
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_ForumComments_CommentId",
                table: "ForumComments",
                column: "CommentId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_BlogComments_CommentId",
                table: "BlogComments",
                column: "CommentId",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_Forums_ForumCategories_ForumCategoryId",
                table: "Forums",
                column: "ForumCategoryId",
                principalTable: "ForumCategories",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Forums_ForumCategories_ForumCategoryId",
                table: "Forums");

            migrationBuilder.DropIndex(
                name: "IX_ForumComments_CommentId",
                table: "ForumComments");

            migrationBuilder.DropIndex(
                name: "IX_BlogComments_CommentId",
                table: "BlogComments");

            migrationBuilder.AlterColumn<int>(
                name: "ForumCategoryId",
                table: "Forums",
                nullable: true,
                oldClrType: typeof(int));

            migrationBuilder.CreateIndex(
                name: "IX_ForumComments_CommentId",
                table: "ForumComments",
                column: "CommentId");

            migrationBuilder.CreateIndex(
                name: "IX_BlogComments_CommentId",
                table: "BlogComments",
                column: "CommentId");

            migrationBuilder.AddForeignKey(
                name: "FK_Forums_ForumCategories_ForumCategoryId",
                table: "Forums",
                column: "ForumCategoryId",
                principalTable: "ForumCategories",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
