﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AVENT.Models
{
    public class OrderStatus
    {
        public int Id { get; set; }
        [Required]
        [StringLength(15)]
        [MinLength(2)]
        public string Name { get; set; }
        public virtual IEnumerable<Order> Orders  { get; set; }
    }
}
