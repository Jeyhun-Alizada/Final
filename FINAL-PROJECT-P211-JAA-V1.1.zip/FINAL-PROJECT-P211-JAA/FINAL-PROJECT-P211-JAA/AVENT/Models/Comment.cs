﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AVENT.Models
{
    public class Comment
    {
        public int Id { get; set; }
        [StringLength(3327)]
        [Required]
        public string Description { get; set; }
        public string UserName{ get; set;}
        public DateTime CreatedAt { get; set; }
        public virtual BlogComments BlogComments { get; set; }
        public virtual ForumComments ForumComments { get; set; }
    }
}
