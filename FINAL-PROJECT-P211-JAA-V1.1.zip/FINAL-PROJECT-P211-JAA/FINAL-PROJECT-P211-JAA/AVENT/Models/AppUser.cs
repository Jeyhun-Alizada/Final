﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace AVENT.Models
{
    public class AppUser : IdentityUser
    {
        [Required]
        [StringLength(75)]
        public string Firstname { get; set; }
        [Required]
        [StringLength(75)]
        public string Lastname { get; set; }
        public DateTime Birthdate { get; set; }
        [StringLength(255)]
        public string Image { get; set; }
        [StringLength(255)]
        public string ImageAlt { get; set; }
        [NotMapped]
        public IFormFile Photo { get; set; }
    }
}