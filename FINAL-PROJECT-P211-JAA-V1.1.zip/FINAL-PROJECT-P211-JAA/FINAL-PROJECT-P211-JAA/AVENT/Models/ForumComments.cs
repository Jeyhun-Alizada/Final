﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AVENT.Models
{
    public class ForumComments
    {
        public int Id { get; set; }
        [Required]
        public int ForumId { get; set; }
        [Required]
        public int CommentId { get; set; }
        public virtual Forum Forum { get; set; }
        public virtual Comment Comment { get; set; }
    }
}
