﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace AVENT.Models
{
    public class Forum
    {
        public int Id { get; set; }
        [StringLength(255)]
        [Required]
        public string Header { get; set; }
        public int ForumCategoryId { get; set; }
        [StringLength(6199)]
        public string Description { get; set; }
        [StringLength(255)]
        public string Image { get; set; }
        [StringLength(255)]
        public string ImageAlt { get; set; }
        public string UserName { get; set; }
        public DateTime CreatedAt { get; set; }
        [NotMapped]
        public IFormFile Photo { get; set; }
        public virtual ForumCategory ForumCategory { get; set; }
    }
}
