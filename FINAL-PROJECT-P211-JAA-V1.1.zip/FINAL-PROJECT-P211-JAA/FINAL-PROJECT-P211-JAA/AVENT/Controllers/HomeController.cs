﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AVENT.DAL;
using AVENT.Models;
using AVENT.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace AVENT.Controllers
{
    public class HomeController : Controller
    {
        private readonly AventDbContext _context;
        public HomeController(AventDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            string cart = HttpContext.Session.GetString("cart");
            List<CartProduct> CartProducts = new List<CartProduct>();
            if (cart != null)
            {
                CartProducts = JsonConvert.DeserializeObject<List<CartProduct>>(cart);
            }
            int count = 0;
            foreach (var item in CartProducts)
            {
                count += item.Quantity;
            }
            @ViewData["count"] = count;
            HomeIndexVM homeIndexVM = new HomeIndexVM
            {
                MainSliders = _context.MainSliders.ToList(),
                BlogSliders = _context.BlogSliders.ToList(),
                ForumSliders = _context.ForumSliders.ToList(),
                Products = _context.Products.ToList(),
                ProductCategories = _context.ProductCategories.ToList()
            };
            return View(homeIndexVM);
        }
        public async Task<IActionResult> Single(int id)
        {
            string cart = HttpContext.Session.GetString("cart");
            List<CartProduct> CartProducts = new List<CartProduct>();
            if (cart != null)
            {
                CartProducts = JsonConvert.DeserializeObject<List<CartProduct>>(cart);
            }
            int count = 0;
            foreach (var item in CartProducts)
            {
                count += item.Quantity;
            }
            @ViewData["count"] = count;

            var product = await _context.Products.FindAsync(id);
            @ViewData["Category"] = _context.ProductCategories.FirstOrDefault(pc => pc.Id == product.ProductCategoryId).Name;
            @ViewData["Brend"] = _context.Brends.FirstOrDefault(pc => pc.Id == product.BrendId).Name;

            return View(product);
        }
        [Route("Home/Product/{filter?}")]
        public IActionResult Product(string filter = null)
        {
            string cart = HttpContext.Session.GetString("cart");
            List<CartProduct> CartProducts = new List<CartProduct>();
            if (cart != null)
            {
                CartProducts = JsonConvert.DeserializeObject<List<CartProduct>>(cart);
            }
            int count = 0;
            foreach (var item in CartProducts)
            {
                count += item.Quantity;
            }
            @ViewData["count"] = count;

            if (filter != null && filter.IndexOf('<') != -1)
            {
                @ViewData["pricefilter"] = filter.Replace("<","");
                decimal priceFilter = Int32.Parse(filter.Replace("<", ""));
                HomeIndexVM homeIndexVMThisBrand = new HomeIndexVM
                {
                    Products = _context.Products.Where(p => p.Price <= priceFilter).ToList(),
                    Brends = _context.Brends.ToList(),
                    ProductCategories = _context.ProductCategories.ToList()
                };
                return View(homeIndexVMThisBrand);
            }
            else if (filter == "IfBestseller")
            {
                HomeIndexVM homeIndexVMOnlyBestsellers = new HomeIndexVM
                {
                    Products = _context.Products.Where(p => p.IfBestseller == true).ToList(),
                    Brends = _context.Brends.ToList(),
                    ProductCategories = _context.ProductCategories.ToList(),
                    Filter = filter
                };
                return View(homeIndexVMOnlyBestsellers);
            }
            else if (filter == "HasDiscount")
            {
                HomeIndexVM homeIndexVMHasDiscount = new HomeIndexVM
                {
                    Products = _context.Products.Where(p => p.HasDiscount == true).ToList(),
                    Brends = _context.Brends.ToList(),
                    ProductCategories = _context.ProductCategories.ToList(),
                    Filter = filter
                };
                return View(homeIndexVMHasDiscount);
            }
            else if (filter == "IfNew")
            {
                HomeIndexVM homeIndexVMIfNew = new HomeIndexVM
                {
                    Products = _context.Products.Where(p => p.IfNew == true).ToList(),
                    Brends = _context.Brends.ToList(),
                    ProductCategories = _context.ProductCategories.ToList(),
                    Filter = filter
                };
                return View(homeIndexVMIfNew);
            }
            else if (filter == "FirstCheap")
            {
                HomeIndexVM homeIndexVMFirstCheap = new HomeIndexVM
                {
                    Products = _context.Products.OrderBy(p => p.Price).ToList(),
                    Brends = _context.Brends.ToList(),
                    ProductCategories = _context.ProductCategories.ToList(),
                    Filter = filter
                };
                return View(homeIndexVMFirstCheap);
            }
            else if (filter == "FirstExpencive")
            {
                HomeIndexVM homeIndexVMFirstExpencive = new HomeIndexVM
                {
                    Products = _context.Products.OrderByDescending(p => p.Price).ToList(),
                    Brends = _context.Brends.ToList(),
                    ProductCategories = _context.ProductCategories.ToList(),
                    Filter = filter
                };
                return View(homeIndexVMFirstExpencive);
            }
            else if (filter != null && filter.IndexOf('-') != -1)
            {
                string afterReplace = filter.Replace("Brend-", "");
                HomeIndexVM homeIndexVMThisBrand = new HomeIndexVM
                {
                    Products = _context.Products.Where(p => p.BrendId.ToString() == afterReplace).ToList(),
                    Brends = _context.Brends.ToList(),
                    ProductCategories = _context.ProductCategories.ToList(),
                    Filter = filter.Replace("Brend-", "")
                };
                return View(homeIndexVMThisBrand);
            }
            else if (filter != null)
            {
                HomeIndexVM homeIndexVMThisCategory = new HomeIndexVM
                {
                    Products = _context.Products.Where(p => p.ProductCategoryId.ToString() == filter).ToList(),
                    Brends = _context.Brends.ToList(),
                    ProductCategories = _context.ProductCategories.ToList()
                };
                return View(homeIndexVMThisCategory);
            }
            HomeIndexVM homeIndexVM = new HomeIndexVM
            {
                Products = _context.Products.ToList(),
                Brends = _context.Brends.ToList(),
                ProductCategories = _context.ProductCategories.ToList()
            };
            return View(homeIndexVM);
        }
        public IActionResult About(string filter = null)
        {
            string cart = HttpContext.Session.GetString("cart");
            List<CartProduct> CartProducts = new List<CartProduct>();
            if (cart != null)
            {
                CartProducts = JsonConvert.DeserializeObject<List<CartProduct>>(cart);
            }
            int count = 0;
            foreach (var item in CartProducts)
            {
                count += item.Quantity;
            }
            @ViewData["count"] = count;

            About about = _context.About.First();
            return View(about);
        }
    }
}