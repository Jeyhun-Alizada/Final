﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AVENT.DAL;
using AVENT.Models;
using AVENT.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace AVENT.Controllers
{

    public class ProfileController : Controller
    {
        private readonly AventDbContext _context;
        private readonly UserManager<AppUser> _userManager;
        public ProfileController(AventDbContext context, UserManager<AppUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }
        public IActionResult Index()
        {
            string cart = HttpContext.Session.GetString("cart");
            List<CartProduct> CartProducts = new List<CartProduct>();
            if (cart != null)
            {
                CartProducts = JsonConvert.DeserializeObject<List<CartProduct>>(cart);
            }
            int count = 0;
            foreach (var item in CartProducts)
            {
                count += item.Quantity;
            }
            @ViewData["count"] = count;

            return View();
        }
        public async Task<IActionResult> Orders()
        {
            string cart = HttpContext.Session.GetString("cart");
            List<CartProduct> CartProducts = new List<CartProduct>();
            if (cart != null)
            {
                CartProducts = JsonConvert.DeserializeObject<List<CartProduct>>(cart);
            }
            int count = 0;
            foreach (var item in CartProducts)
            {
                count += item.Quantity;
            }
            @ViewData["count"] = count;

            AppUser user = await _userManager.FindByNameAsync(User.Identity.Name);
            List<Order> orders = new List<Order>();
            for (int i = 0; i < _context.Orders.Count(); i++)
            {
                if (_context.Orders.ToArray()[i].CustomerId == user.Id)
                {
                    Order order = new Order
                    {
                        Id = _context.Orders.ToArray()[i].Id,
                        Number = _context.Orders.ToArray()[i].Number,
                        OrderStatusId = _context.Orders.ToArray()[i].OrderStatusId,
                        CraetedAt = _context.Orders.ToArray()[i].CraetedAt,
                        Total = _context.Orders.ToArray()[i].Total
                    };
                    orders.Add(order);
                };

            }
            OrderVM orderVM = new OrderVM
            {
                OrderStatus = _context.OrderStatus.ToList(),
                Orders = orders
            };

            return View(orderVM);
        }
        public async Task<IActionResult> Order( int Id)
        {
            string cart = HttpContext.Session.GetString("cart");
            List<CartProduct> CartProducts = new List<CartProduct>();
            if (cart != null)
            {
                CartProducts = JsonConvert.DeserializeObject<List<CartProduct>>(cart);
            }
            int count = 0;
            foreach (var item in CartProducts)
            {
                count += item.Quantity;
            }
            @ViewData["count"] = count;

            OrderVM orderVM = new OrderVM
            {
                Order = await _context.Orders.FindAsync(Id),
                Products = _context.Products.ToList(),
                OrderProducts = _context.OrderProducts.Where(op => op.OrderId == Id).ToList(),
                OrderStatus = _context.OrderStatus.ToList()
            };
            return View(orderVM);
        }
    }
}