﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using AVENT.Models;
using AVENT.ViewModels;
using AVENT.DAL;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Identity;

namespace AVENT.Controllers
{
    public class CheckoutController : Controller
    {
        private readonly AventDbContext _context;
        private readonly UserManager<AppUser> _userManager;
        public CheckoutController(AventDbContext context, UserManager<AppUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }
        public async Task<IActionResult> Add(int id)
        {
            Product product = await _context.Products.FindAsync(id);
            CartProduct cartProduct = product;

            string cart = HttpContext.Session.GetString("cart");

            List<CartProduct> cartProducts = new List<CartProduct>();

            if (cart != null)
            {
                cartProducts = JsonConvert.DeserializeObject<List<CartProduct>>(cart);
            }
            var selected = cartProducts.FirstOrDefault(p => p.Id == id);
            if (selected == null)
            {
                cartProducts.Add(cartProduct);
            }
            else
            {
                selected.Quantity += 1;
            }
            string productsJSON = JsonConvert.SerializeObject(cartProducts);
            HttpContext.Session.SetString("cart", productsJSON);

            return Ok(new
            {
                status = 200,
                error = "",
                data = ""
            });
        
         }
        public IActionResult Change(string Id)
        {
            string cart = HttpContext.Session.GetString("cart");
            List<CartProduct> CartProducts = new List<CartProduct>();

            if (cart != null)
            {
                CartProducts = JsonConvert.DeserializeObject<List<CartProduct>>(cart);
            }
            int before = int.Parse(Id.Split('m')[0].Replace("m", ""));
            var selected = CartProducts.FirstOrDefault(p => p.Id == before);
            int after = int.Parse(Id.Split('m')[1].Replace("m", ""));
            if(after <= 0)
            {
                CartProducts.Remove(selected);
            }
            else
            {
                selected.Quantity = after;
            }
            string productsJSON = JsonConvert.SerializeObject(CartProducts);
            HttpContext.Session.SetString("cart", productsJSON);

            return Ok(new
            {
                status = 200,
                data = "",
                error = ""
            });
        }
        public IActionResult Remove(int id)
        {
            string cart = HttpContext.Session.GetString("cart");

            List<CartProduct> CartProducts = new List<CartProduct>();

            if (cart != null)
            {
                CartProducts = JsonConvert.DeserializeObject<List<CartProduct>>(cart);
            }
            var selected = CartProducts.FirstOrDefault(p => p.Id == id);
            CartProducts.Remove(selected);
            string productsJSON = JsonConvert.SerializeObject(CartProducts);
            HttpContext.Session.SetString("cart", productsJSON);

            return Ok(new
            {
                status = 200,
                data = "",
                error = ""
            });
        }
        public IActionResult Index()
        {
            string cart = HttpContext.Session.GetString("cart");
            List<CartProduct> CartProducts = new List<CartProduct>();
            if (cart != null)
            {
                CartProducts = JsonConvert.DeserializeObject<List<CartProduct>>(cart);
            }
            HomeIndexVM homeIndexVM = new HomeIndexVM
            {
                CartProducts = CartProducts,
            };
            int count = 0;
            foreach (var item in CartProducts)
            {
                count += item.Quantity;
            }
            @ViewData["count"] = count;
            return View(homeIndexVM);
        }
        public async Task<IActionResult> Send(string id)
        {
            if (User.Identity.IsAuthenticated)
            {
                string cart = HttpContext.Session.GetString("cart");
                AppUser customer = await _userManager.FindByNameAsync(User.Identity.Name);
                Order newOrder = new Order
                {
                    CustomerId = customer.Id,
                    Cart = cart,
                    Total = Convert.ToDecimal(id),
                    CraetedAt = DateTime.Now,
                    OrderStatusId = 1,
                    Number = "10010"
                };
                await _context.Orders.AddAsync(newOrder);
                await _context.SaveChangesAsync();
                List<CartProduct> CartProducts = new List<CartProduct>();

                if (cart != null)
                {
                    CartProducts = JsonConvert.DeserializeObject<List<CartProduct>>(cart);
                }
                foreach (var cartProduct in CartProducts)
                {
                    for (int i = 0; i < cartProduct.Quantity; i++)
                    {
                        OrderProducts orderProductModel = new OrderProducts
                        {
                            ProductId = cartProduct.Id,
                            OrderId = newOrder.Id
                        };
                        await _context.OrderProducts.AddAsync(orderProductModel);
                        await _context.SaveChangesAsync();
                    }
                }
                Order update = await _context.Orders.FindAsync(newOrder.Id);
                update.Number = newOrder.Number + newOrder.Id.ToString();
                _context.Orders.Update(update);
                await _context.SaveChangesAsync();

                return Ok(new
                {
                    status = 200,
                    error = "",
                    data = ""
                });
            }
            else
            {
                return RedirectToAction("Login", "Auth");
            }
        }
        public async Task<IActionResult> Status(string Id)
        {
            if (User.Identity.IsAuthenticated)
            {
                int before = int.Parse(Id.Split('s')[0].Replace("m", ""));
                Order update = await _context.Orders.FindAsync(before);
                int after = int.Parse(Id.Split('s')[1].Replace("m", ""));
                update.OrderStatusId = after;
                _context.Orders.Update(update);
                await _context.SaveChangesAsync();
                return Ok(new
                {
                    status = 200,
                    error = "",
                    data = ""
                });
            }
            else
            {
                return RedirectToAction("Login", "Auth");
            }
        }
    }
}