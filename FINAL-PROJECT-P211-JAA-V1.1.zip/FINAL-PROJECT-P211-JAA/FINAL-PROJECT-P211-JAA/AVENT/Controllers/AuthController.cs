﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using AVENT.Models;
using AVENT.ViewModels;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace AVENT.Controllers
{
    public class AuthController : Controller
    {
        private readonly UserManager<AppUser> _userManager;
        private readonly SignInManager<AppUser> _signInManager;
        public AuthController(UserManager<AppUser> userManager, SignInManager<AppUser> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
        }
        public IActionResult Register()
        {
            string cart = HttpContext.Session.GetString("cart");
            List<CartProduct> CartProducts = new List<CartProduct>();
            if (cart != null)
            {
                CartProducts = JsonConvert.DeserializeObject<List<CartProduct>>(cart);
            }
            int count = 0;
            foreach (var item in CartProducts)
            {
                count += item.Quantity;
            }
            @ViewData["count"] = count;
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterVM registerVM)
        {
            if (!ModelState.IsValid)
            { 

                return View(registerVM);
            }
            AppUser appUser = new AppUser
            {
                Email = registerVM.Email,
                Firstname = registerVM.Firstname,
                Lastname = registerVM.Lastname,
                UserName = registerVM.Username
            };
            IdentityResult result = await _userManager.CreateAsync(appUser, registerVM.Password);
            if (result.Succeeded)
            {
                return RedirectToAction(nameof(Login));
            }
            else
            {
                foreach (IdentityError error in result.Errors)
                {
                    ModelState.AddModelError("", error.Description);
                }
                return View(registerVM);
            }
        }
        public IActionResult Login()
        {
            string cart = HttpContext.Session.GetString("cart");
            List<CartProduct> CartProducts = new List<CartProduct>();
            if (cart != null)
            {
                CartProducts = JsonConvert.DeserializeObject<List<CartProduct>>(cart);
            }
            int count = 0;
            foreach (var item in CartProducts)
            {
                count += item.Quantity;
            }
            @ViewData["count"] = count;
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginVM loginVM)
        {
            if (!ModelState.IsValid) return View(loginVM);
            AppUser user = await _userManager.FindByEmailAsync(loginVM.Email);
            if (user == null)
            {
                ModelState.AddModelError("", "Email or password is invalid");
                return View(loginVM);
            }
            var result = await _signInManager.PasswordSignInAsync(user, loginVM.Password, loginVM.RememberMe, true);
            if (!result.Succeeded)
            {
                ModelState.AddModelError("", "Email or password is invalid");
                return View(loginVM);
            }
            return RedirectToAction("Index", "Home");
        }
        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();
            return RedirectToAction("Index", "Home");
        }
    }
}