﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AVENT.DAL;
using AVENT.ViewModels;

namespace AVENT.Controllers
{
    public class AjaxController : Controller
    {
        private readonly AventDbContext _context;
        public AjaxController(AventDbContext context)
        {
            _context = context;
        }
        public IActionResult Load(int skip)
        {
            var products = _context.Products.OrderByDescending(p => p.Name).Skip(skip).Take(3);
            return Ok(new
            {
                status = 200,
                message = "",
                data = products
            });
        }
    }
}