﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AVENT.DAL;
using AVENT.Models;
using AVENT.ViewModels;
using Microsoft.AspNetCore.Identity;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;
using AVENT.Extations;
using static AVENT.Utilities.Utilities;
namespace AVENT.Controllers
{
    public class BlogController : Controller
    {
        private readonly AventDbContext _context;
        private readonly IHostingEnvironment _env;
        private readonly UserManager<AppUser> _userManager;
        public BlogController(AventDbContext context, IHostingEnvironment env, UserManager<AppUser> userManager)
        {
            _context = context;
            _env = env;
            _userManager = userManager;
        }
        [Route("Blog/Index/{filter?}")]
        public IActionResult Index(string filter = null)
        {
            string cart = HttpContext.Session.GetString("cart");
            List<CartProduct> CartProducts = new List<CartProduct>();
            if (cart != null)
            {
                CartProducts = JsonConvert.DeserializeObject<List<CartProduct>>(cart);
            }
            int count = 0;
            foreach (var item in CartProducts)
            {
                count += item.Quantity;
            }
            @ViewData["count"] = count;

            if (filter != null && filter.IndexOf('%') != -1)
            {
                string filterletters = filter.Replace("%", "");
                //List<Blog> blogs = new List<Blog>();
                //foreach (var item in _context.Blogs.Where(b => b.Description.Contains(filterletters)).First())
                //{
                //    if(item == true)
                //    {

                //    };

                //}
                PostVM postVM = new PostVM
                {
                    Blogs = _context.Blogs.Where(b => b.Description.Contains(filterletters)).ToList(),
                    Blog = _context.Blogs.Where(b => b.Description.Contains(filterletters)).First()
            };
                return View(postVM);
            }
            else if (filter != null)
            {
                if (_context.Blogs.Where(b => b.UserName == filter).Count() > 0)
                {
                    PostVM postVM = new PostVM
                    {
                        Blogs = _context.Blogs.Where(b => b.UserName == filter).ToList()
                    };
                    return View(postVM);
                }
                else
                {
                    PostVM postVM = new PostVM
                    {
                        Blogs = _context.Blogs.ToList()
                    };
                    return View(postVM);
                }
            }
            else
            {
                PostVM postVM = new PostVM
                {
                    Blogs = _context.Blogs.ToList()
                };
                return View(postVM);
            }
        }
        public IActionResult Single(int Id)
        {
            string cart = HttpContext.Session.GetString("cart");
            List<CartProduct> CartProducts = new List<CartProduct>();
            if (cart != null)
            {
                CartProducts = JsonConvert.DeserializeObject<List<CartProduct>>(cart);
            }
            int count = 0;
            foreach (var item in CartProducts)
            {
                count += item.Quantity;
            }
            @ViewData["count"] = count;
            PostVM postVM = new PostVM
            {
                Blog = _context.Blogs.Where(b => b.Id == Id).FirstOrDefault(),
                Blogs = _context.Blogs.Take(5).ToList(),
                Comments = _context.Comments.Where(c => c.BlogComments.BlogId == Id).ToList()
            };
            return View(postVM);
        }
        public async Task<IActionResult> Remove(int id)
        {
            if (id == null) return NotFound();
            var post = await _context.Blogs.FindAsync(id);
            if (post == null) return NotFound();
            RemoveFile(post.Image, _env.WebRootPath);
            _context.Blogs.Remove(post);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        public async Task<IActionResult> Comment(string Id)
        {
            if (User.Identity.IsAuthenticated)
            {
                AppUser commenter = await _userManager.FindByNameAsync(User.Identity.Name);
                int before = int.Parse(Id.Split('c')[0].Replace("c", ""));
                string after = Id.Split('c')[1].Replace("c", "");
                Comment comment = new Comment
                {
                    UserName = commenter.UserName,
                    CreatedAt = DateTime.Now,
                    Description = after
                };
                await _context.Comments.AddAsync(comment);
                await _context.SaveChangesAsync();
                BlogComments blogComment = new BlogComments
                {
                    BlogId = before,
                    CommentId = comment.Id
                };
                await _context.BlogComments.AddAsync(blogComment);
                await _context.SaveChangesAsync();

                return Ok(new
                {
                    status = 200,
                    error = "",
                    data = ""
                });
            }
            else
            {
                return RedirectToAction("Login", "Auth");
            }
        }
        public async Task<IActionResult> Delete(int id)
        {
            if (id == null) return NotFound();
            var comment = await _context.Comments.FindAsync(id);
            if (comment == null) return NotFound();
            _context.Comments.Remove(comment);
            await _context.SaveChangesAsync();
            return Ok(new
            {
                status = 200,
                data = "",
                error = ""
            });
        }
        public IActionResult Add()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Add(Blog blog)
        {
            AppUser user = await _userManager.FindByNameAsync(User.Identity.Name);
            if (!ModelState.IsValid)
            {
                return View(blog);
            }
            if (blog.Photo == null)
            {
                ModelState.AddModelError("Photo", "Photo should be selected");
                return View(blog);
            }
            if (!blog.Photo.IsImage())
            {
                ModelState.AddModelError("Photo", "Photo is not valid");
                return View(blog);
            }

            blog.Image = await blog.Photo.SaveFileAsync(_env.WebRootPath);
            blog.UserName = user.UserName;
            blog.CreatedAt = DateTime.Now;
            await _context.Blogs.AddAsync(blog);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}