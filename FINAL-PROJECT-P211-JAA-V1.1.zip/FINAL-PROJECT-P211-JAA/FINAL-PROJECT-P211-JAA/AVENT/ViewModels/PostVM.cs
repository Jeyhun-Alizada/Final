﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AVENT.Models;

namespace AVENT.ViewModels
{
    public class PostVM
    {
        public List<Blog> Blogs { get; set; }
        public Blog Blog { get; set; }
        public List<Forum> Forums { get; set; }
        public Forum Forum { get; set; }
        public List<Comment> Comments { get; set; }
        public List<ForumCategory> ForumCategories { get; set; }
    }
}
