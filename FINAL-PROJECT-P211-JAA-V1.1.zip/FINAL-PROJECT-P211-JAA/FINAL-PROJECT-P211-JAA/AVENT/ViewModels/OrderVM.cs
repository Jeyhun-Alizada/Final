﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AVENT.Models;

namespace AVENT.ViewModels
{
    public class OrderVM
    {
        public List<Order> Orders { get; set; }
        public Order Order { get; set; }
        public List<Product> Products { get; set; }
        public List<CartProduct> CartProducts { get; set; }
        public List<OrderProducts> OrderProducts { get; set; }
        public List<OrderStatus> OrderStatus { get; set; }
    }
}
