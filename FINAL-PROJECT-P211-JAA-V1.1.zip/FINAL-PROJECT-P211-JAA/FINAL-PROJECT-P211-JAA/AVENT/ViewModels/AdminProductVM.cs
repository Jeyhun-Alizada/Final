﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AVENT.Models;

namespace AVENT.ViewModels
{
    public class AdminProductVM
    {
        public List<Product> Products { get; set; }
        public List<ProductCategory> ProductCategories { get; set; }
    }
}
