﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using AVENT.Models;

namespace AVENT.ViewModels
{
    public class RegisterVM
    {
        [Required(ErrorMessage = "Email qeyd olunmalıdır.")]
        [MinLength(5)]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        [Required(ErrorMessage = "İstifadəçi adı qeyd olmalıdır.")]
        public string Username { get; set; }

        [Required(ErrorMessage = "Ad qeyd olunmalıdır.")]
        [MinLength(3)]
        public string Firstname { get; set; }

        public string Lastname { get; set; }

        [Required(ErrorMessage = "Şifrə təyin olmalıdır.")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Required(ErrorMessage = "Şifrə təyin olmalıdır."), Compare(nameof(Password),ErrorMessage ="Şifrə uyğun gəlmir.")]
        [DataType(DataType.Password)]
        public string ConfirmPassword { get; set; }
    }
}