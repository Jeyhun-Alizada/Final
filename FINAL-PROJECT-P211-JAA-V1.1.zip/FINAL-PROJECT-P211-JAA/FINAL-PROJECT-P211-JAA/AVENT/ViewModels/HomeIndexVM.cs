﻿using AVENT.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AVENT.ViewModels
{
    public class HomeIndexVM
    {
        public List<MainSlider> MainSliders { get; set; }
        public List<Product> Products { get; set; }
        public List<BlogSlider> BlogSliders { get; set; }
        public List<ForumSlider> ForumSliders { get; set; }
        public List<Brend> Brends { get; set; }
        public List<ProductCategory> ProductCategories { get; set; }
        public List<CartProduct> CartProducts { get; set; }
        public Product Product { get; set; }
        public string Filter { get; set; }
    }
}