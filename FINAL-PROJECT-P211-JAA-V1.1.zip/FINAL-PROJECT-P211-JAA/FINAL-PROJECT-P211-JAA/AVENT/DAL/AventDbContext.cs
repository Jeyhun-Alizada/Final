﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using AVENT.Models;

namespace AVENT.DAL
{
    public class AventDbContext : IdentityDbContext<AppUser>
    {
        public AventDbContext(DbContextOptions<AventDbContext> options) : base(options)
        {
        }

        public DbSet<ProductCategory> ProductCategories { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Blog> Blogs { get; set; }
        public DbSet<ForumCategory> ForumCategories { get; set; }
        public DbSet<Forum> Forums { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<Comment> Comments { get; set; }
        public DbSet<About> About { get; set; }
        public DbSet<Contact> Contact { get; set; }
        public DbSet<MainSlider> MainSliders { get; set; }
        public DbSet<BlogSlider> BlogSliders { get; set; }
        public DbSet<ForumSlider> ForumSliders { get; set; }
        public DbSet<Brend> Brends { get; set; }
        public DbSet<OrderProducts> OrderProducts { get; set; }
        public DbSet<OrderStatus> OrderStatus { get; set; }
        public DbSet<BlogComments> BlogComments { get; set; }
        public DbSet<ForumComments> ForumComments { get; set; }
    }
}
